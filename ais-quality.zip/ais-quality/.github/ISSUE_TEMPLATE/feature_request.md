---
name: Feature request
about: Suggest a focused improvement to AIS auditing
---
## Problem and user workflow

## Proposed behavior

## Synthetic example and expected output

## Alternatives and limitations
