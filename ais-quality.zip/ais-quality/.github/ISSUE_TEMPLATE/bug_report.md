---
name: Bug report
about: A reproducible problem with validation, installation or exports
---
## Expected behavior

## Actual behavior

## Reproduction
Command and small synthetic CSV (no sensitive data):

## Environment
AIS Quality version, Python version, OS, ML dependency version (if enabled):

## Logs
Remove private paths and data before posting.
